package com.jantabank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingApplicationForJantaBankApplicationTests {

//Test
//new test
//test 3

//test 2

	@Test
	void contextLoads() {
	}

}
