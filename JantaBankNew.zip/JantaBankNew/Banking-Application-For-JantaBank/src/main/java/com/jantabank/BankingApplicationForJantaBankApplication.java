package com.jantabank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication()
public class BankingApplicationForJantaBankApplication {
	public static void main(String[] args) {
		SpringApplication.run(BankingApplicationForJantaBankApplication.class, args);
	}
}
